# UTS Big Data

Nama      : Muzadi Ramli</br>
NIM       : B34180040</br>
Prodi     : Teknik Informatika 2018 A</br>

